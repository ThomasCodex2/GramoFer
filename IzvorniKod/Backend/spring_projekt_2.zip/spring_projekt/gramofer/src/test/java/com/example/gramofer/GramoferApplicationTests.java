package com.example.gramofer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GramoferApplicationTests {

	@Test
	void contextLoads() {
	}

}
