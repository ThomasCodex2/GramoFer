package com.example.gramofer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GramoferApplication {

	public static void main(String[] args) {
		SpringApplication.run(GramoferApplication.class, args);
	}

}
